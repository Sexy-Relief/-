import numpy as np
import math


def display(input_txt_path, output_txt_path):
    import matplotlib.pyplot as plt
    
    '''
    input1 : input_txt_path = path of input_example.txt
    input2 : output_txt_path = path of output_example.txt
    return : save convex_hull image
    '''
    
    with open(input_txt_path, "r") as f:
        input_lines = f.readlines()
    with open(output_txt_path, "r") as f:
        output_lines = f.readlines()
    whole_points = input_lines
    area = round(float(output_lines[0]), 1)
    hull_points = output_lines[1:]

    x_list = [int(x.split(" ")[0]) for x in whole_points]
    y_list = [int(x.split(" ")[1]) for x in whole_points]
    plt.plot(x_list, y_list, marker='.', linestyle='None')

    hx_list = [int(x.split(" ")[0]) for x in hull_points]
    hy_list = [int(x.split(" ")[1]) for x in hull_points]

    plt.plot(hx_list, hy_list, marker='*', linestyle='None', markersize=10)

    title = plt.title(f'Area : {area}')
    plt.setp(title, color='r')
    plt.savefig(output_txt_path[:-3]+"png", bbox_inches='tight')


def open_input_file(input_path):
    with open(input_path, "r") as f:
        input_lines = f.readlines()
    whole_points = input_lines
    x_list = [int(x.split(" ")[0]) for x in whole_points]
    y_list = [int(x.split(" ")[1]) for x in whole_points]
    pts = list()
    for i in range(len(x_list)):
        pts.append((x_list[i], y_list[i]))
    return pts


def ccw(p1,p2,p3):
    vec1 = (p2[0]-p1[0],p2[1]-p1[1])
    vec2 = (p3[0]-p1[0],p3[1]-p1[1])
    return vec1[0]*vec2[1]-vec1[1]*vec2[0]


def comp(p1, p2):
    if p1[0] == p2[0]:
        if p1[1] < p2[1]:
            return math.inf
        elif p1[1] == p2[1]:
            return 0
        else:
            return (-1)*math.inf

    return (p2[1]-p1[1])/(p2[0]-p1[0])


def sort_by_ccw(pts):
    base_pt_idx = pts.index(min(pts))
    pts[0], pts[base_pt_idx] = pts[base_pt_idx], pts[0]
    pt = [pts[0]] + sorted(pts[1:], key=lambda x: comp(pts[0], x))
    return pt


def get_area(pts):
    accum=0
    cur = pts[0]
    for point in pts[1:]:
        accum += cur[0]*point[1]
        accum -= cur[1]*point[0]
        cur = point
    accum += pts[0][1]*pts[-1][0]
    accum -= pts[0][0]*pts[-1][1]

    return abs(accum)*0.5


def get_convex_points(pts):
    pts = sort_by_ccw(pts)
    hull = list()
    for point in pts:
        while len(hull) > 1 and ccw(hull[-2], hull[-1], point) <= 0:
            hull.pop(-1)
        hull.append(point)
    return hull


def is_in_polygon(hull, point):
    hull.append(hull[0])
    cur = hull[1]
    base = ccw(hull[0], hull[1], point)
    for nxt in hull[2:]:
        if ccw(cur, nxt, point)*base < 0:
            return 'out'
        cur = nxt
    else:
        return 'in'


if __name__ == "__main__":
    #for input 1
    input_txt = "./input1.txt"
    pts = open_input_file(input_txt)
    convex = get_convex_points(pts)
    area = get_area(convex)
    f = open("안도현_output1.txt", "w")
    f.write(str(area)+'\n')
    for p in convex:
        f.write(str(p[0])+" "+str(p[1])+'\n')
    f.close()
    display("./input1.txt", "./안도현_output1.txt")

    input2_txt = "./point_in_polygon_input.txt"
    pts2 = open_input_file(input2_txt)
    rt = list()
    for p in pts2:
        rt.append(is_in_polygon(convex, p))
    f = open("안도현_point_in_polygon_output1.txt", "w")
    for a in rt:
        f.write(a+'\n')
    f.close()

    # for input 2
    input_txt = "./input2.txt"
    pts = open_input_file(input_txt)
    convex = get_convex_points(pts)
    area = get_area(convex)
    f = open("안도현_output2.txt", "w")
    f.write(str(area) + '\n')
    for p in convex:
        f.write(str(p[0]) + " " + str(p[1]) + '\n')
    f.close()
    display("./input2.txt", "./안도현_output2.txt")

    input2_txt = "./point_in_polygon_input.txt"
    pts2 = open_input_file(input2_txt)
    rt = list()
    for p in pts2:
        rt.append(is_in_polygon(convex, p))
    f = open("안도현_point_in_polygon_output2.txt", "w")
    for a in rt:
        f.write(a + '\n')
    f.close()


# for input 3
    input_txt = "./input3.txt"
    pts = open_input_file(input_txt)
    convex = get_convex_points(pts)
    area = get_area(convex)
    f = open("안도현_output3.txt", "w")
    f.write(str(area) + '\n')
    for p in convex:
        f.write(str(p[0]) + " " + str(p[1]) + '\n')
    f.close()
    display("./input3.txt", "./안도현_output3.txt")

    input2_txt = "./point_in_polygon_input.txt"
    pts2 = open_input_file(input2_txt)
    rt = list()
    for p in pts2:
        rt.append(is_in_polygon(convex, p))
    f = open("안도현_point_in_polygon_output3.txt", "w")
    for a in rt:
        f.write(a + '\n')
    f.close()
